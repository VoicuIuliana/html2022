
for (var j = 1; j <= 10; j++) {
    document.write( "<br> " +"<br>" + "Multiplication table: " + j);
    for (var i = 1; i <= 10; i++) {
        document.write("<br>" + j + "*" + i + "=" + (i * j));
    }
}
